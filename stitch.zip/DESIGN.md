# Design System Specification

## 1. Overview & Creative North Star: "The Intelligent Lens"
This design system moves away from the rigid, boxy layouts of legacy enterprise software. Our Creative North Star is **"The Intelligent Lens"**—a concept focused on clarity, optical depth, and editorial precision. 

In recruitment, data is noise until it is focused. This system uses intentional asymmetry, expansive negative space, and tonal layering to guide the eye toward what matters. We avoid "template" aesthetics by prioritizing a "no-line" philosophy, treating the UI as a series of sophisticated, stacked surfaces rather than a flat grid. The result is an experience that feels less like a database and more like a high-end digital concierge.

---

## 2. Colors & Surface Philosophy
The palette centers on deep, authoritative blues (`#131b2e`) and slates (`#515f74`), energized by a high-performance Electric Indigo (`#392cc1`).

### The "No-Line" Rule
**Explicit Instruction:** Do not use 1px solid borders to section content. Layout boundaries must be defined exclusively through background color shifts or tonal transitions. 
*   *Implementation:* Place a `surface-container-low` (`#f2f3ff`) element against a `surface` (`#faf8ff`) background to create a soft, sophisticated edge.

### Surface Hierarchy & Nesting
Treat the UI as physical layers of "frosted glass." Use the surface tiers to create nested depth:
*   **Base Layer:** `surface` (#faf8ff) for global backgrounds.
*   **Secondary Layer:** `surface-container-low` (#f2f3ff) for sidebar or secondary navigation zones.
*   **Primary Interaction Layer:** `surface-container-lowest` (#ffffff) for the main content cards or focus areas.
*   **Elevated Detail:** `surface-container-high` (#e2e7ff) for transient elements like hover states or active selection indicators.

### The "Glass & Gradient" Rule
To inject "soul" into the AI experience, the primary CTA and key hero elements should utilize subtle gradients.
*   **Action Gradient:** Transition from `primary` (#392cc1) to `primary-container` (#534ad9) at a 135-degree angle.
*   **Glassmorphism:** For floating modals or dropdowns, use `surface-container-lowest` at 80% opacity with a `24px` backdrop blur to allow underlying colors to bleed through softly.

---

## 3. Typography: The Editorial Scale
We pair the geometric precision of **Manrope** for high-impact display with the functional clarity of **Inter** for data-heavy utility.

*   **Display & Headlines (Manrope):** Use `display-lg` (3.5rem) and `headline-md` (1.75rem) to create an authoritative, editorial feel. Tracking should be tightened slightly (-2%) for headlines to feel more cohesive.
*   **Body & UI (Inter):** Use `body-lg` (1rem) for candidate descriptions and `label-md` (0.75rem) for metadata. 
*   **The Intent:** Large, high-contrast headline scales convey the "Intelligence" of the platform, while the highly legible Inter ensures "Efficiency" during long periods of resume screening.

---

## 4. Elevation & Depth
We eschew traditional drop shadows in favor of **Tonal Layering**.

*   **The Layering Principle:** Depth is achieved by stacking. A `surface-container-lowest` card sitting on a `surface-container-low` background provides enough contrast to be perceived as "elevated" without a shadow.
*   **Ambient Shadows:** For floating action buttons or critical popovers, use a shadow with a blur radius of `40px`, an offset of `y: 8px`, and an opacity of 6%. The shadow color must be a tint of `on-surface` (#131b2e) to ensure it feels like a natural light occlusion rather than a grey smudge.
*   **The "Ghost Border" Fallback:** If accessibility requires a border (e.g., in high-contrast scenarios), use `outline-variant` (#c7c4d8) at **15% opacity**. Never use a 100% opaque border.

---

## 5. Components

### Primary Action Button
*   **Styling:** Gradient fill (`primary` to `primary-container`), `xl` (0.75rem) corner radius.
*   **State:** On hover, the gradient should shift slightly in saturation. No harsh borders.
*   **Typography:** `title-sm` (Inter), semi-bold, white text.

### Intuitive Upload Areas
*   **Styling:** Instead of a dashed line, use a large `surface-container-low` area with a central `primary` icon. 
*   **Interaction:** Upon drag-over, transition the background to `surface-container-high` and apply a subtle `0.5rem` inner glow using the `surface-tint`.

### Input Fields
*   **Styling:** Soft `surface-container-low` background. 
*   **Focus State:** A 2px "Ghost Border" using `primary` at 40% opacity. Avoid heavy outlines.
*   **Labels:** Use `label-md` in `on-surface-variant` (#464555), positioned slightly above the field with generous leading.

### Cards & Lists
*   **The "No-Divider" Rule:** Forbid 1px dividers between list items. Use a `16px` vertical gap (Spacing Scale) and a subtle change in background color on hover (`surface-container-highest`) to distinguish items.

### AI Suggestion Chips
*   **Styling:** `tertiary-container` (#006693) background with `on-tertiary-container` (#b8e0ff) text. Use `full` (9999px) roundedness to contrast against the more architectural rectangular elements.

---

## 6. Do’s and Don’ts

### Do
*   **DO** use whitespace as a structural element. If a section feels cluttered, increase the padding before adding a line.
*   **DO** use `manrope` for any text that serves as a brand moment or high-level summary.
*   **DO** ensure that the `electric indigo` accent is used sparingly for primary actions to maintain its visual "vibrancy."

### Don't
*   **DON'T** use pure black (#000000) for text. Always use `on-surface` (#131b2e) for deep contrast that remains sophisticated.
*   **DON'T** use standard `md` (0.375rem) rounding for large containers. Use `xl` (0.75rem) to keep the aesthetic modern and approachable.
*   **DON'T** use 100% opaque borders. They break the "The Intelligent Lens" metaphor and create visual friction.